/var/www/*/logs/*.log {
        daily
        missingok
        rotate 7
        compress
        delaycompress
        create
        sharedscripts
        postrotate
                [ ! -f /var/run/{{pid_file}} ] || kill -USR1 `cat /var/run/{{pid_file}}`
        endscript
}
